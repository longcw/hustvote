-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014-12-11 10:51:26
-- 服务器版本: 5.5.40-0ubuntu0.14.04.1
-- PHP 版本: 5.5.9-1ubuntu4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `hustvote`
--

-- --------------------------------------------------------

--
-- 表的结构 `Choice`
--

CREATE TABLE IF NOT EXISTS `Choice` (
  `choiceid` int(11) NOT NULL AUTO_INCREMENT,
  `start_voteid` int(11) NOT NULL,
  `choice_name` varchar(255) NOT NULL,
  `choice_intro` text,
  PRIMARY KEY (`choiceid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

--
-- 转存表中的数据 `Choice`
--

INSERT INTO `Choice` (`choiceid`, `start_voteid`, `choice_name`, `choice_intro`) VALUES
(11, 2000, '高兴', ''),
(12, 2000, '忧桑', ''),
(13, 2000, '兴奋', ''),
(14, 2000, '抑郁', ''),
(15, 2000, '逗比', ''),
(16, 2000, '生气', ''),
(17, 2000, '怒不可遏', ''),
(18, 2000, '激动', ''),
(19, 2001, '1', ''),
(20, 2001, '2', ''),
(21, 2002, '1', ''),
(22, 2002, '2', ''),
(23, 2003, '1221', ''),
(24, 2003, '1212', ''),
(25, 2004, '1', ''),
(26, 2004, '2', ''),
(27, 2005, '1', ''),
(28, 2005, '1', ''),
(29, 2006, '高兴', '<header style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" data-original-title="" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/6001/" title="如果在清朝有电视机，播放的内容可能会是什么？ - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">如果在清朝有电视机，播放的内容可能会是什么？</a></h2><small class="text-muted" data-original-title="" title="" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;">梁萧 发布于 12小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><a href="http://bohaishibei.com/post/6001/" class="thumbnail" style="box-sizing: border-box; color: rgb(118, 189, 255); outline: 0px; background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/51a6ad6b4c52dc502ab2948e0da03cc6.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); font-size: 14px; line-height: 22px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;">作者：伊字诀各位观众晚上好，今天是嘉庆九年十一月初一，西洋历一千八百四年十二月初二，欢迎收看新闻联播，今天的主要内容有——奉天承运，皇上作出重要指示，严惩白莲教叛乱；军机处反腐败委员会清查湖北军饷滥支案，案件造成不良社会...</p><p><br/></p>'),
(30, 2006, '逗比', '<header style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5997/" title="微语录精选1207：宝哥哥，你的金箍棒真是让金莲乐不思蜀呀 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">微语录精选1207：宝哥哥，你的金箍棒真是让金莲乐不思蜀呀</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><a href="http://bohaishibei.com/post/5997/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/1c9e22d4084bb50d1e4c0a108ec4dd97.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); font-size: 14px; line-height: 22px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;">吴宇森老了。在文化方面，人老了，贵在深度思考，缺乏思考能力者适合颐养天年。很不幸，吴不是个有深度思考能力的人。对太平轮这种片子，用烂片形容不准确。对这部群星汇聚的片子，我想起了一部电视剧片名：星光灿烂猪八戒。本要打造一个...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(3385)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(2)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e5%be%ae%e8%af%ad%e5%bd%95/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">微语录</a>&nbsp;/&nbsp;<a href="http://bohaishibei.com/post/tag/%e8%af%ad%e5%bd%95%e7%b2%be%e9%80%89/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">语录精选</a></span></p><p><br/></p>'),
(31, 2006, '生气', '<header style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5992/" title="朝阳区情怀创业指南 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">朝阳区情怀创业指南</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><a href="http://bohaishibei.com/post/5992/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/a277bfa3f666f502d855d4c3cd6d9bee.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); font-size: 14px; line-height: 22px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;">“这个年关并不好过。”喝完面前那碗还散着幽幽猪屎味的卤煮汤，刘大仁波切痛心疾首道。作为朝阳区二十万未续费活佛之一，我和这位在金融街卖佛牌的同学，都已经在连续创业的路上滚过了第四个年头。几年前，刘大和阿雷一起给特美有品供贴...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px; font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; white-space: normal;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(937)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(1)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e6%9c%9d%e9%98%b3%e5%8c%ba/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">朝阳区</a></span></p><p><br/></p>');
INSERT INTO `Choice` (`choiceid`, `start_voteid`, `choice_name`, `choice_intro`) VALUES
(32, 2007, '测试', '<article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" data-original-title="" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/6002/" title="怀疑从ATM机里取出假币怎么办？ - 博海拾贝" style="box-sizing: border-box; color: rgb(118, 189, 255); text-decoration: underline; outline: 0px; transition: all 0.218s linear; -webkit-transition: all 0.218s linear; background: transparent;">怀疑从ATM机里取出假币怎么办？</a></h2><small class="text-muted" data-original-title="" title="" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 12小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/6002/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/93836086b50cddc0f9e3c91d2ca916b2.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(1864)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(4)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/atm%e6%9c%ba/" rel="tag" data-original-title="" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">ATM机</a>&nbsp;/&nbsp;<a href="http://bohaishibei.com/post/tag/%e5%81%87%e5%b8%81/" rel="tag" data-original-title="" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">假币</a></span></p></article><p><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" data-original-title="" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/6001/" title="如果在清朝有电视机，播放的内容可能会是什么？ - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">如果在清朝有电视机，播放的内容可能会是什么？</a></h2><small class="text-muted" data-original-title="" title="" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 12小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/6001/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/51a6ad6b4c52dc502ab2948e0da03cc6.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">作者：伊字诀各位观众晚上好，今天是嘉庆九年十一月初一，西洋历一千八百四年十二月初二，欢迎收看新闻联播，今天的主要内容有——奉天承运，皇上作出重要指示，严惩白莲教叛乱；军机处反腐败委员会清查湖北军饷滥支案，案件造成不良社会...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(1275)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(2)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e7%94%b5%e8%a7%86%e6%9c%ba/" rel="tag" data-original-title="" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">电视机</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/tao/" data-original-title="" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">优惠<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/6000/" title="精品好货！达宁胜 男士自动扣皮带    21 款可选   15.8 元包邮 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">精品好货！达宁胜 男士自动扣皮带 21 款可选 15.8 元包邮</a></h2><small class="text-muted" data-original-title="" title="" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>1</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 12小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/6000/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/b62b515d32641bf1534889e57bf0ed96.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">这款男士自动扣皮带带身尺寸长110-125cm，宽3.5cm，精选上等优质牛皮，富有光泽，柔韧度好，抗皱耐磨性强，不易裂皮，不易断裂，纹理清晰细腻，手感舒适。精品五合金材料打制扣头，时尚精美，经久耐用，时尚商务休闲男士首...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(369)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(0)</span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/videos/" data-original-title="" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">视频<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5998/" title="龙斌大话《变形金刚4》 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">龙斌大话《变形金刚4》</a></h2><small class="text-muted" data-original-title="" title="" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5998/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/7d13697be419c126da559a988423d53d.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">感觉就是动作场面过多，少了一些剧情的画面，2个半小时看了七八成动作，会累的。IOS通道...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(504)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(0)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e5%8f%98%e5%bd%a2%e9%87%91%e5%88%9a4/" rel="tag" data-original-title="" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">变形金刚4</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5997/" title="微语录精选1207：宝哥哥，你的金箍棒真是让金莲乐不思蜀呀 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">微语录精选1207：宝哥哥，你的金箍棒真是让金莲乐不思蜀呀</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5997/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/1c9e22d4084bb50d1e4c0a108ec4dd97.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">吴宇森老了。在文化方面，人老了，贵在深度思考，缺乏思考能力者适合颐养天年。很不幸，吴不是个有深度思考能力的人。对太平轮这种片子，用烂片形容不准确。对这部群星汇聚的片子，我想起了一部电视剧片名：星光灿烂猪八戒。本要打造一个...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(3385)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(2)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e5%be%ae%e8%af%ad%e5%bd%95/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">微语录</a>&nbsp;/&nbsp;<a href="http://bohaishibei.com/post/tag/%e8%af%ad%e5%bd%95%e7%b2%be%e9%80%89/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">语录精选</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/videos/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">视频<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5996/" title="不同省份的中国人,容易得什么病 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">不同省份的中国人,容易得什么病</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5996/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/428fca9bc1921c25c5121f9da7815cde.03.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">一方水土养一方人，一方水土也能养一方病，北京肠癌发病率高，上海是胃癌，广东是鼻咽癌，江苏是肝癌。东北人心脑血管发病率高，南方人容易得肾结石，常吃面食容易得糖尿病，吃海鲜多容易得痛风。不同地区的流行病不但与地理环境和生活习...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(1584)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(0)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e4%b8%ad%e5%9b%bd%e4%ba%ba/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">中国人</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/pics/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">图片<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5995/" title="也不知道是哪个丧心病狂给这些动物p上了手，竟然毫无违和感 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">也不知道是哪个丧心病狂给这些动物p上了手，竟然毫无违和感</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>5</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5995/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/e8c496caec3008366e685b50068fa200.gif&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(1965)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(0)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e5%8a%a8%e7%89%a9/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">动物</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5994/" title="56岁的《星期日邮报》专栏作家模仿麦当娜拍照 奇葩且色情 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">56岁的《星期日邮报》专栏作家模仿麦当娜拍照 奇葩且色情</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>8</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5994/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/3f3a63b285f84289df98a631ed19d8c3.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">一名正在英国《星期日邮报》（MailonSunday）工作的专栏女作家丽斯（Liz）突发奇想要拍摄一组和美国著名女星麦当娜，她说她和女星麦当娜一样都是56岁，一样努力工作，都喜欢运动和瑜伽。她表示她对当年麦当娜接受采访时...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(1458)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(1)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e6%8b%8d%e7%85%a7/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">拍照</a>&nbsp;/&nbsp;<a href="http://bohaishibei.com/post/tag/%e8%89%b2%e6%83%85/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">色情</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/pics/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">图片<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5993/" title="神脑洞的作品 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">神脑洞的作品</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>1</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5993/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/abdf973418cfd31e0f697b4965e36959.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">一个学画画的哥们出门都有带着小本子东画西画的习惯。。。。很快。。他就觉得光画风景太无聊了。。。。。于是就有了下面这些神脑洞的作品。。。。。。。。。会画画的人再加上大脑洞简直无敌了好嘛。。(@英国那些事儿)...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(2282)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(3)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e8%84%91%e6%b4%9e/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">脑洞</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/digest/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">文摘<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5992/" title="朝阳区情怀创业指南 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">朝阳区情怀创业指南</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>2</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 13小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5992/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/a277bfa3f666f502d855d4c3cd6d9bee.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">“这个年关并不好过。”喝完面前那碗还散着幽幽猪屎味的卤煮汤，刘大仁波切痛心疾首道。作为朝阳区二十万未续费活佛之一，我和这位在金融街卖佛牌的同学，都已经在连续创业的路上滚过了第四个年头。几年前，刘大和阿雷一起给特美有品供贴...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(937)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(1)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e6%9c%9d%e9%98%b3%e5%8c%ba/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">朝阳区</a></span></p></article><article class="excerpt excerpt-one" style="box-sizing: border-box; padding: 25px 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(238, 238, 238); position: relative; overflow: hidden; color: rgb(68, 68, 68); font-family: &#39;Microsoft Yahei&#39;, &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><header style="box-sizing: border-box; margin: 0px 0px 10px;"><a class="cat label label-important" href="http://bohaishibei.com/post/category/pics/" style="box-sizing: border-box; position: relative; padding: 5px 7px 4px; font-size: 10.152px; opacity: 0.9; margin-right: 5px; top: -2px; background: rgb(118, 189, 255);">图片<em class="label-arrow" style="box-sizing: border-box; position: absolute; width: 0px; height: 0px; vertical-align: top; content: &#39;&#39;; top: 7px; right: -4px; border-left-width: 4px; border-left-style: solid; border-left-color: rgb(118, 189, 255); border-top-width: 4px; border-top-style: solid; border-top-color: transparent; border-bottom-width: 4px; border-bottom-style: solid; border-bottom-color: transparent; opacity: 0.9;"></em></a><h2 style="box-sizing: border-box; font-family: inherit; font-weight: normal; line-height: 25px; color: inherit; margin-top: 0px; margin-bottom: 0px; font-size: 22px; display: inline; position: relative; top: 1px;"><a href="http://bohaishibei.com/post/5991/" title="三点透视图 - 博海拾贝" style="box-sizing: border-box; color: rgb(68, 68, 68); -webkit-transition: all 0.218s linear; transition: all 0.218s linear; background: transparent;">三点透视图</a></h2><small class="text-muted" style="box-sizing: border-box; font-size: 12px; color: rgb(153, 153, 153); margin-left: 10px;"><span class="glyphicon glyphicon-picture" style="box-sizing: border-box; position: relative; top: 1px; display: inline-block; font-family: &#39;Glyphicons Halflings&#39;; line-height: 1; -webkit-font-smoothing: antialiased; margin-right: 2px; font-size: 13px;"></span>1</small></header><p class="text-muted time" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;">梁萧 发布于 14小时前</p><p class="focus" style="box-sizing: border-box; margin-top: -15px; margin-right: -6px; margin-bottom: 0px; position: relative; overflow: hidden; float: right; width: 182.15625px;"><a href="http://bohaishibei.com/post/5991/" class="thumbnail" style="box-sizing: border-box; color: rgb(68, 68, 68); background: transparent;"><img src="http://106.186.116.72/thumb/thumb.php?src=http://dulei.si/files/2014/12/08/cd56be61acb2105a397a70b9282748aa.jpg&w=240&h=180&zc=1" class="thumb" style="box-sizing: border-box; max-width: 240px; width: 182.15625px; max-height: 132px; height: 132px;"/></a></p><p class="note" style="box-sizing: border-box; margin-top: 6px; margin-right: 182.15625px; margin-bottom: 10px; padding-right: 15px; color: rgb(119, 119, 119); line-height: 22px;">今天看见一个人用一个关键词就完全展现了Google和Baidu图片搜索之间的区别及内涵。。。这个词就是#三点透视图#。。。(@星空下的巫师)...</p><p class="text-muted views" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; color: rgb(153, 153, 153); font-size: 12px;"><span class="post-views" style="box-sizing: border-box; margin-right: 20px;">阅读(2930)</span><span class="post-comments" style="box-sizing: border-box; margin-right: 20px;">评论(9)</span><span class="post-tags" style="box-sizing: border-box; margin-right: 20px;">标签：<a href="http://bohaishibei.com/post/tag/%e9%80%8f%e8%a7%86/" rel="tag" style="box-sizing: border-box; color: rgb(153, 153, 153); text-decoration: underline; background: transparent;">透视</a></span></p></article></p><p><br/></p>'),
(33, 2007, '无测试', ''),
(34, 2008, '1221', ''),
(35, 2008, '2121', ''),
(36, 2009, '1212', ''),
(37, 2009, '1212', ''),
(38, 2010, 'qwwq', ''),
(39, 2010, 'qwqw', ''),
(40, 2011, '111', ''),
(41, 2011, '2222', ''),
(42, 2012, '1', ''),
(43, 2012, '1', ''),
(44, 2013, '12', ''),
(45, 2013, '12', ''),
(46, 2014, '啦啦', ''),
(47, 2014, '哈哈', ''),
(48, 2014, '哈哈哈', '');

-- --------------------------------------------------------

--
-- 表的结构 `Code`
--

CREATE TABLE IF NOT EXISTS `Code` (
  `codeid` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '-1表示系统自动创建',
  `start_voteid` int(11) NOT NULL,
  `is_voted` tinyint(1) NOT NULL DEFAULT '0',
  `vote_time` varchar(32) DEFAULT NULL,
  `logid` int(11) DEFAULT NULL,
  PRIMARY KEY (`codeid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `Code`
--

INSERT INTO `Code` (`codeid`, `code`, `uid`, `start_voteid`, `is_voted`, `vote_time`, `logid`) VALUES
(1, '14759452d8', 7, 2000, 0, NULL, NULL),
(2, '12513777b0', 7, 2000, 0, NULL, NULL),
(3, 'a9657a8fe', 7, 2000, 0, NULL, NULL),
(4, '31712e02b', 7, 2014, 1, '1418265751', NULL),
(5, 'a0154e900', 7, 2014, 1, '1418265864', NULL),
(6, '924cb628d', 7, 2014, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `Group`
--

CREATE TABLE IF NOT EXISTS `Group` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(255) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `Group`
--

INSERT INTO `Group` (`groupid`, `groupname`) VALUES
(1, '普通用户'),
(2, '管理员'),
(3, '超级管理员');

-- --------------------------------------------------------

--
-- 表的结构 `JoinVote`
--

CREATE TABLE IF NOT EXISTS `JoinVote` (
  `join_voteid` int(11) NOT NULL AUTO_INCREMENT,
  `start_voteid` int(11) NOT NULL,
  `logid` int(11) NOT NULL COMMENT 'VoteLogId',
  `choiceid` int(11) NOT NULL,
  `createtime` varchar(64) NOT NULL,
  PRIMARY KEY (`join_voteid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- 转存表中的数据 `JoinVote`
--

INSERT INTO `JoinVote` (`join_voteid`, `start_voteid`, `logid`, `choiceid`, `createtime`) VALUES
(5, 2000, 2, 14, '1418007380'),
(6, 2000, 2, 15, '1418007380'),
(7, 2000, 2, 17, '1418007380'),
(8, 2000, 3, 14, '1418007444'),
(9, 2000, 3, 17, '1418007444'),
(10, 2002, 4, 22, '1418025988'),
(11, 2004, 5, 25, '1418049285'),
(12, 2000, 6, 11, '1418050385'),
(13, 2000, 6, 12, '1418050385'),
(14, 2000, 6, 13, '1418050385'),
(15, 2007, 7, 33, '1418054852'),
(16, 2007, 8, 32, '1418100965'),
(17, 2002, 9, 21, '1418101997'),
(18, 2008, 10, 34, '1418102032'),
(19, 2006, 11, 29, '1418107703'),
(20, 2006, 11, 30, '1418107703'),
(21, 2007, 12, 32, '1418175150'),
(22, 2000, 13, 11, '1418175197'),
(23, 2000, 13, 12, '1418175197'),
(24, 2000, 13, 13, '1418175197'),
(25, 2010, 14, 38, '1418182624'),
(26, 2011, 15, 40, '1418190336'),
(27, 2000, 16, 12, '1418218521'),
(28, 2000, 16, 15, '1418218521'),
(29, 2000, 16, 18, '1418218521'),
(30, 2013, 17, 44, '1418224169'),
(31, 2013, 18, 44, '1418263290'),
(32, 2014, 19, 47, '1418265864'),
(33, 2014, 19, 48, '1418265864');

-- --------------------------------------------------------

--
-- 表的结构 `StartVote`
--

CREATE TABLE IF NOT EXISTS `StartVote` (
  `start_voteid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `intro` text,
  `summary` varchar(500) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `choice_max` int(11) NOT NULL COMMENT '一次最多投几项',
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) NOT NULL COMMENT '结束时间',
  `create_time` varchar(64) NOT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否完成',
  PRIMARY KEY (`start_voteid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2015 ;

--
-- 转存表中的数据 `StartVote`
--

INSERT INTO `StartVote` (`start_voteid`, `uid`, `title`, `intro`, `summary`, `image`, `choice_max`, `start_time`, `end_time`, `create_time`, `is_completed`) VALUES
(2000, 7, '多选投票样例', '<p style="margin-top: 0px; margin-bottom: 10px; font-family: &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; line-height: normal; white-space: normal;"><img src="http://localhost:8088/umeditor/php/upload/20141208/14180070444450.jpg" _src="http://localhost:8088/umeditor/php/upload/20141208/14180070444450.jpg"/></p><p style="margin-top: 0px; margin-bottom: 10px; font-family: &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; line-height: normal; white-space: normal;">你认为下面那些词语能够描绘你此时的心情和状态？</p>', '你认为下面那些词语能够描绘你此时的心情和状态？', 'http://localhost:8088/umeditor/php/upload/20141208/14180070444450.jpg', 3, '1418007099', '-1', '1418007099', 1),
(2001, 7, '看图心理测试', '<p><span style="font-family: &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; line-height: normal; white-space: normal;"><img src="http://localhost:8088/umeditor/php/upload/20141208/14180075155404.jpg" _src="http://localhost:8088/umeditor/php/upload/20141208/14180075155404.jpg"/></span></p><p><span style="font-family: &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; line-height: normal; white-space: normal;">这个测验其实挺有趣的：有一幅图画，有一个英挺、身穿战甲的战士正骑着马，在一望无际的原野中急速向前奔腾。请问如果要你在这幅画加个东西，你会最想加上什么物品呢？</span></p>', '这个测验其实挺有趣的：有一幅图画，有一个英挺、身穿战甲的战士正骑着马，在一望无际的原野中急速向前奔腾', 'http://localhost:8088/umeditor/php/upload/20141208/14180075155404.jpg', 1, '1418007600', '1418004000', '1418007540', 0),
(2002, 7, '1212', '<p>1212</p>', '1212', '', 1, '1418025965', '-1', '1418025965', 0),
(2003, 7, '1212', '<p>1212</p>', '1212', '', 1, '1418027145', '-1', '1418027145', 0),
(2004, 7, '1212', '<p>1211</p>', '1211', '', 1, '1418029731', '-1', '1418029731', 0),
(2005, 7, '1212', '<p>11</p>', '11', '', 1, '1418051311', '-1', '1418051311', 0),
(2006, 7, '富文本选项测试', '<p style="margin-top: 0px; margin-bottom: 10px; line-height: normal; font-family: &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;"><img src="http://localhost:8088/umeditor/php/upload/20141208/14180070444450.jpg" _src="http://localhost:8088/umeditor/php/upload/20141208/14180070444450.jpg"/></p><p style="margin-top: 0px; margin-bottom: 10px; line-height: normal; font-family: &#39;Helvetica Neue&#39;, Helvetica, Arial, sans-serif; font-size: 14px; white-space: normal;">你认为下面那些词语能够描绘你此时的心情和状态？</p><p><br/></p>', '你认为下面那些词语能够描绘你此时的心情和状态？', 'http://localhost:8088/umeditor/php/upload/20141208/14180070444450.jpg', 2, '1418053057', '-1', '1418053057', 0),
(2007, 7, '长选项测试', '<p>啊啊啊</p>', '啊啊啊', '', 1, '1418053402', '-1', '1418053402', 0),
(2008, 7, '1212', '<p>1212</p>', '1212', '', 1, '1418055225', '-1', '1418055225', 0),
(2009, 7, '1212', '<p>sdds</p>', 'sdds', '', 1, '1418137762', '1418137740', '1418137762', 0),
(2010, 7, 'wqwq', '<p>qwqw</p>', 'qwqw', '', 1, '1418182603', '-1', '1418182603', 0),
(2011, 7, '111', '<p>111</p>', '111', '', 1, '1418187582', '-1', '1418187582', 1),
(2012, 7, '1212', '<p>12112</p>', '12112', '', 1, '1418223549', '-1', '1418223549', 1),
(2013, 7, '1212', '<p>12122121</p>', '12122121', '', 1, '1418223776', '-1', '1418223776', 1),
(2014, 7, '验证码测试', '<p>121212</p>', '121212', '', 2, '1418265500', '-1', '1418265500', 1);

-- --------------------------------------------------------

--
-- 表的结构 `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `groupid` int(11) NOT NULL COMMENT '用户组ID',
  `nickname` varchar(255) NOT NULL COMMENT '昵称',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '邮箱是否验证',
  `verify_token` varchar(64) DEFAULT NULL,
  `exp_time` varchar(32) DEFAULT NULL,
  `createtime` varchar(64) NOT NULL COMMENT '注册时间',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `User`
--

INSERT INTO `User` (`uid`, `email`, `password`, `groupid`, `nickname`, `is_verified`, `verify_token`, `exp_time`, `createtime`) VALUES
(3, '123@qqq.cc', '111111', 1, 'ddd', 0, NULL, NULL, '1417347286'),
(4, '123@qq.ww', '111111', 1, 's', 0, NULL, NULL, '1417348286'),
(5, '123@qqq.ccd', '111111', 1, 's', 0, NULL, NULL, '1417348471'),
(6, '123@qqq.ccdw', '111111', 1, 's', 0, NULL, NULL, '1417348579'),
(7, '361571243@qq.com', '111111', 1, '小坚果', 1, 'd7da880779ec26ebaa5bf7ff83692da5', '0', '1417350328');

-- --------------------------------------------------------

--
-- 表的结构 `VoteLimit`
--

CREATE TABLE IF NOT EXISTS `VoteLimit` (
  `limitid` int(11) NOT NULL AUTO_INCREMENT,
  `start_voteid` int(11) NOT NULL,
  `ip_address` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否限制ip',
  `captcha_need` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要验证码',
  `cycle_time` int(11) NOT NULL DEFAULT '0' COMMENT '是否可以过一段时间继续投票',
  `code_need` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否须要邀请码',
  `email_need` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要邮箱验证',
  `email_limit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否限制邮箱域名',
  `email_area` varchar(300) DEFAULT NULL COMMENT '邮箱域名',
  PRIMARY KEY (`limitid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `VoteLimit`
--

INSERT INTO `VoteLimit` (`limitid`, `start_voteid`, `ip_address`, `captcha_need`, `cycle_time`, `code_need`, `email_need`, `email_limit`, `email_area`) VALUES
(1, 2000, 1, 0, 6, 0, 0, 0, NULL),
(2, 2001, 1, 1, 0, 0, 0, 0, NULL),
(3, 2002, 0, 0, 12, 0, 1, 0, NULL),
(4, 2003, 1, 1, 0, 1, 0, 0, NULL),
(5, 2004, 1, 1, 12, 0, 1, 1, 'hust.edu.cn'),
(6, 2005, 1, 0, 0, 0, 0, 0, NULL),
(7, 2006, 1, 0, 0, 0, 0, 0, NULL),
(8, 2007, 1, 1, 12, 0, 0, 0, NULL),
(9, 2008, 1, 1, 0, 0, 0, 0, NULL),
(10, 2009, 1, 1, 0, 0, 0, 0, NULL),
(11, 2010, 1, 1, 0, 0, 0, 0, NULL),
(12, 2011, 1, 1, 0, 0, 0, 0, NULL),
(13, 2012, 1, 1, 0, 0, 0, 0, NULL),
(14, 2013, 1, 1, 6, 0, 0, 0, NULL),
(15, 2014, 1, 1, 0, 1, 0, 0, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `VoteLog`
--

CREATE TABLE IF NOT EXISTS `VoteLog` (
  `logid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `start_voteid` int(11) NOT NULL,
  `fingerprint` varchar(64) DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `session_id` varchar(64) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `openid` varchar(64) DEFAULT NULL COMMENT 'type:id  第三方id',
  `thirdtype` varchar(64) DEFAULT NULL COMMENT '第三方类型 qq，微信等',
  `via` varchar(32) NOT NULL COMMENT 'web;android',
  `vote_time` varchar(32) NOT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `VoteLog`
--

INSERT INTO `VoteLog` (`logid`, `uid`, `start_voteid`, `fingerprint`, `ip_address`, `session_id`, `email`, `code`, `openid`, `thirdtype`, `via`, `vote_time`) VALUES
(2, 7, 2000, '3251202011', '127.0.0.1', 'd5446fa1853b49cb13d7251d0529417c', '361571243@qq.com', '', NULL, NULL, 'web', '1418007380'),
(3, NULL, 2000, '487739692', '127.0.0.1', 'c20b2476ec6c1f0939c14295d8aa3eaa', NULL, '', NULL, NULL, 'web', '1418007444'),
(4, 7, 2002, '3251202011', '127.0.0.1', '048ffd7bb963d41d5cb5c8357f310e98', '361571243@qq.com', '', NULL, NULL, 'web', '1418025988'),
(5, 7, 2004, '3251202011', '127.0.0.1', '08bc1ecd405ca2b077f78b1642a1af6b', '361571243@qq.com', '', NULL, NULL, 'web', '1418049285'),
(6, 7, 2000, '3251202011', '127.0.0.1', 'f59726e957a1d329f240c092bc3e76b8', '361571243@qq.com', '', NULL, NULL, 'web', '1418050385'),
(7, 7, 2007, '3251202011', '127.0.0.1', '825e0a443021c256846c6fa79e95aa21', '361571243@qq.com', '', NULL, NULL, 'web', '1418054852'),
(8, NULL, 2007, '3251202011', '127.0.0.1', 'bd299ebd2762cef4191a4a8822924b0a', NULL, '', NULL, NULL, 'web', '1418100965'),
(9, 7, 2002, '3251202011', '127.0.0.1', '7cd6b341703d73955478680c64abed16', '361571243@qq.com', '', NULL, NULL, 'web', '1418101997'),
(10, 7, 2008, '3251202011', '127.0.0.1', '7cd6b341703d73955478680c64abed16', '361571243@qq.com', '', NULL, NULL, 'web', '1418102032'),
(11, 7, 2006, '3251202011', '127.0.0.1', 'ad966b1b014f4959080fbfd59154c8a5', '361571243@qq.com', '', NULL, NULL, 'web', '1418107703'),
(12, NULL, 2007, '3251202011', '127.0.0.1', '00bf737b8baafeafe26c4d3fdf110946', NULL, '', NULL, NULL, 'web', '1418175150'),
(13, NULL, 2000, '3251202011', '127.0.0.1', '00bf737b8baafeafe26c4d3fdf110946', NULL, '', NULL, NULL, 'web', '1418175197'),
(14, 7, 2010, '3251202011', '127.0.0.1', '741449abdd9af912b5f022722f95bc21', '361571243@qq.com', '', NULL, NULL, 'web', '1418182624'),
(15, 7, 2011, '3251202011', '127.0.0.1', '5f9b9743f1d455e2ae53764232ea8035', '361571243@qq.com', '', NULL, NULL, 'web', '1418190336'),
(16, NULL, 2000, '3251202011', '127.0.0.1', '3a5a47037e1f3c5b3462813c368d4912', NULL, '', NULL, NULL, 'web', '1418218521'),
(17, 7, 2013, '3251202011', '127.0.0.1', '31174550777249a82addaac6a0d208db', '361571243@qq.com', '', NULL, NULL, 'web', '1418224169'),
(18, 7, 2013, '3251202011', '127.0.0.1', '67cc2c27dffe843c2eff16769d6f9525', '361571243@qq.com', '', NULL, NULL, 'web', '1418263290'),
(19, 7, 2014, '3251202011', '127.0.0.1', '02ff82b25b636b04beff98d46500fd89', '361571243@qq.com', 'a0154e900', NULL, NULL, 'web', '1418265864');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
